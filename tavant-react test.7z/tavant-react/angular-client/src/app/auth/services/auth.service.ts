import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  loadUser() {
    throw new Error('Method not implemented.');
  }
  registerUser(newUser: any) {
    throw new Error('Method not implemented.');
  }
  stringify(newUser: any) {
    throw new Error('Method not implemented.');
  }

  constructor() {}
}
