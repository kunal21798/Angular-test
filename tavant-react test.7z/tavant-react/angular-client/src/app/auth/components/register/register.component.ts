import { Component, OnInit } from '@angular/core';
import { Register } from '../../models/register';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(private authService: AuthService, private router: Router) {}

  registerSubmit() {
    console.log(JSON.stringify(this.register));

    const newUser: any = {
      name: this.register.name,
      email: this.register.email,
      password: this.register.password,
    };
    this.authService.registerUser(newUser).subscribe(
      (res) => {
        console.log('user registered successfully');
        localStorage.setItem('token', res.token);
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log('user registeration failed');
      }
    );
  }

  ngOnInit(): void {}
}
