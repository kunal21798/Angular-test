import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CreateProfileService {
  getProfile() {
    throw new Error("Method not implemented.");
  }

  constructor() { }
}
