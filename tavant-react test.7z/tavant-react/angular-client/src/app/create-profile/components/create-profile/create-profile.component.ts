import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/profiles/models/profile';
import { ActivatedRoute } from '@angular/router';
import { ProfilesService } from 'src/app/profiles/services/profiles.service';
import jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  profile: Profile;
  token: any;
  data: any;

  constructor(
    private route: ActivatedRoute,
    private profileService: ProfilesService
  ) {}

  ngOnInit(): void {
    this.token = localStorage.getItem('token');
    if (this.token) {
      this.data = jwt_decode(this.token);
      console.log(this.data);
    }
  }
}
